#include "Player.h"
#include <iostream>
std::string Player::ChooseAction()
{
    int Input;
    while (true)
    {
		std::cout << "Choose your action (1. Attack 2. Parry 3. Defend): ";
        std::cin >> Input;
        if (std::cin.fail() || Input < 1 || Input > 3)
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "Invalid input. Please enter a number between 1 and 3(Attack, Parry, Defend).\n";
        }
        else {
            break;
        }
    }
    Input -= 1;
	return GetActionFromInput(Input);
}
