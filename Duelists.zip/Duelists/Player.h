#pragma once
#include "Character.h"

class Player : public Character {
public:
	Player(int Amount, int AttackPower, int Armor, std::string Name) : Character(Amount, AttackPower, Armor, Name) {};
	std::string ChooseAction() override;

};