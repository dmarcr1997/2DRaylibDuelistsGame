#pragma once
#include <string>
#include <iostream>
class Character {
public:
	Character(int health, int attack, int armor, std::string name) : Health(health), AttackPower(attack), Armor(armor), Name(name) {};
	int GetHealth() const { return Health; }
	int GetAttackPower() const { return AttackPower; }
	void UpdateHealth(int Amount);
	bool IsAlive() const { return Health > 0; }
	virtual std::string ChooseAction() = 0;
	std::string GetActionFromInput(int Input);
	std::string GetName() const { return Name; }

protected:
	std::string Name;
	int Health;
	int AttackPower;
	int Armor;
};