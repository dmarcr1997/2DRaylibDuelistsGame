#include "Enemy.h"

Enemy::Enemy(int Amount, int AttackPower, int Armor, std::string Name) : Character(Amount, AttackPower, Armor, Name), Generator(std::random_device{}()), Distribution(0,2) {}


std::string Enemy::ChooseAction()
{
	int Action = Distribution(Generator);
	return GetActionFromInput(Action);
}

void Enemy::IncreaseDifficulty(int RoundNumber)
{
	switch (RoundNumber) {
	case 1:
		return;
	case 2:
		Name = "Orc";
		Health = RoundNumber;
		break;
	case 3:
		Name = "Troll";
		Health = RoundNumber;
		AttackPower = RoundNumber;
		break;
	case 4:
		Name = "Ogre";
		Health = RoundNumber;
		AttackPower = RoundNumber;
		break;
	case 5:
		Name = "Dragon";
		Health = RoundNumber;
		AttackPower = RoundNumber;
		Armor = RoundNumber / 2;
		break;
	}
}
