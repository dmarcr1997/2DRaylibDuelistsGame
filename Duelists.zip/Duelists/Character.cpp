#include "Character.h"

void Character::UpdateHealth(int Amount)
{
	std::cout << Name << " health changed by: " << Amount << "\n";
	Health += Amount;
	std::cout << Name << " health is now: " << (Health < 0 ? 0 : Health) << "\n";
}

std::string Character::GetActionFromInput(int Input)
{
	switch (Input) {
	case 0:
		return "Attack";
	case 1:
		return "Parry";
	case 2:
		return "Defend";
	default:
		return "Invalid Action";
	}
}
