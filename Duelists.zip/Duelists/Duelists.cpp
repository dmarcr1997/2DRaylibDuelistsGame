// Duelists.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <random>
#include "Player.h"
#include "Enemy.h"

bool CheckParrySuccess(int difficulty)
{
	std::mt19937 Generator(std::random_device{}());
	std::uniform_int_distribution<> Distribution(1, 10);
	int Roll = Distribution(Generator);
	return Roll > difficulty;
}

int main()
{
    Player MainPlayer(5, 2, 2, "Hero");
	Enemy MainEnemy(1, 1, 0, "Goblin");
	int RoundNumber = 1;
	while (MainPlayer.IsAlive()) {

		std::string PlayerAction = MainPlayer.ChooseAction();
		std::string MainEnemyAction = MainEnemy.ChooseAction();
		std::cout << "------------------------------------------\n";
		std::cout << "Player " << PlayerAction << "s \t | \t";
		std::cout << "Enemy " << MainEnemyAction << "s\n";
		std::cout << "------------------------------------------\n";

		if (PlayerAction == "Attack") {
			if (MainEnemyAction == "Attack") {
				std::cout << "Its a clash! The weapons ring as they hit eachother!\n";
			}
			else if (MainEnemyAction == "Defend") {
				std::cout << MainEnemy.GetName() << " blocks your attack!\n";
				MainEnemy.UpdateHealth(-(MainPlayer.GetAttackPower() / 2));
			}
			else if (MainEnemyAction == "Parry") {
				std::cout << MainEnemy.GetName() << " parries your attack and \n";
				if (CheckParrySuccess(10 - (RoundNumber + 1))) {
					std::cout << "counters!\n";
					MainPlayer.UpdateHealth(-(MainEnemy.GetAttackPower() * 2));
				}
				else {
					std::cout << "fails to counter!\n";
					MainEnemy.UpdateHealth(-(MainPlayer.GetAttackPower() * 2));
				}
			}
		}
		else if (PlayerAction == "Defend") {
			if (MainEnemyAction == "Attack") {
				std::cout << "You block " << MainEnemy.GetName() << "'s attack!\n";
				MainPlayer.UpdateHealth(-(MainEnemy.GetAttackPower() / 2));
			}
			else if (MainEnemyAction == "Defend") {
				std::cout << "You and " << MainEnemy.GetName() << " both defend, nothing happens.\n";
			}
			else if (MainEnemyAction == "Parry") {
				std::cout << MainEnemy.GetName() << " tries to parry, but you are defending!\n";
			}
		}
		else if (PlayerAction == "Parry") {
			if (MainEnemyAction == "Attack") {
				std::cout << "You parry " << MainEnemy.GetName() << "'s attack and \n";
				if (CheckParrySuccess(10 - RoundNumber)) {
					std::cout << "counter!\n";
					MainEnemy.UpdateHealth(-(MainPlayer.GetAttackPower() * 2));
				}
				else {
					std::cout << "fail to counter!\n";
					MainPlayer.UpdateHealth(-(MainEnemy.GetAttackPower() * 2));
				}
				
			}
			else if (MainEnemyAction == "Defend") {
				std::cout << "You try to parry, but " << MainEnemy.GetName() << " is defending!\n";
			}
			else if (MainEnemyAction == "Parry") {
				std::cout << "You and " << MainEnemy.GetName() << " both try to parry, nothing happens.\n";
			}
		}
		std::cout << std::endl;

		if (!MainEnemy.IsAlive()) {
			std::cout << "You have defeated " << MainEnemy.GetName() << "!\n\n";
			RoundNumber++;
			if (RoundNumber > 5) {
				std::cout << "You have defeated all enemies! You win!\n";
				break;
			}
			MainEnemy.IncreaseDifficulty(RoundNumber);

			std::cout << "------------------------------------------\n";
			std::cout << "Now facing: " << MainEnemy.GetName() << " (Health: " << MainEnemy.GetHealth() << ", Attack: " << MainEnemy.GetAttackPower() << ", Armor: " << MainEnemy.GetHealth() << ")\n\n";
		}
	}
	if(!MainPlayer.IsAlive()) {
		std::cout << "You have been defeated! Game Over!\n";
	}
	std::cout << "Thanks for playing!\n";
	return 0;
}
